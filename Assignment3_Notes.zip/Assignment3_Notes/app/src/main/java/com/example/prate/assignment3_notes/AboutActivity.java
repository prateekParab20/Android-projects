package com.example.prate.assignment3_notes;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by prate on 2/12/2018.
 */

public class AboutActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}
