package com.example.prate.notepad;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.JsonWriter;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    EditText E1;
    TextView T1;
    String str;
    DateFormat dateFormat;
    String date;
    JsonReader jr;
    JsonWriter jw;
    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            E1 = (EditText) findViewById(R.id.editText);
            T1 = (TextView) findViewById(R.id.textView2);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    @Override
    protected void onResume() {
        super.onResume();

        try {
            jr = new JsonReader(new InputStreamReader(openFileInput("user.json"),"UTF-8"));
            jr.beginObject();
            while (jr.hasNext()) {
                String name = jr.nextName();
                if (name.equals("Date")) {
                    T1.setText(jr.nextString());
                } else if (name.equals("Notes")) {
                    E1.setText(jr.nextString());
                }
            }
            jr.endObject();
            jr.close();
        }
        catch(Exception e)
        {
            if (e instanceof FileNotFoundException){
                System.out.println("File is not present, New file will be created !!!");
                dateFormat = new SimpleDateFormat("EEE, d MMM yy hh:mm:ss a");
                date=dateFormat.format(Calendar.getInstance().getTime());
                T1.setText("Last Update: "+date);
            }
            Log.d("MainActivity.java","On Resume");
            e.printStackTrace();
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        str=E1.getText().toString();
        dateFormat = new SimpleDateFormat("EEE, d MMM yy hh:mm:ss a");
        date=dateFormat.format(Calendar.getInstance().getTime());

        try {
            jw = new JsonWriter(new OutputStreamWriter(openFileOutput("user.json", Context.MODE_PRIVATE), "UTF-8"));
            jw.beginObject();
            jw.name("Date").value("Last Update: " + date);
            jw.name("Notes").value(str);
            jw.endObject();
            jw.close();
        }
        catch(Exception e)
        {
            Log.d("MainActivity.java","On Pause");
            e.printStackTrace();
        }
    }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        T1.setText(savedInstanceState.getString(date));
        E1.setText(savedInstanceState.getString(str));
        super.onRestoreInstanceState(savedInstanceState);
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString(str, E1.getText().toString());
        outState.putString(date, T1.getText().toString());
        super.onSaveInstanceState(outState);
    }
    @Override
    protected void onStop(){
        super.onStop();
        str=E1.getText().toString();
        dateFormat = new SimpleDateFormat("EEE, d MMM yy hh:mm:ss a");
        date=dateFormat.format(Calendar.getInstance().getTime());

        try {
            jw = new JsonWriter(new OutputStreamWriter(openFileOutput("user.json", Context.MODE_PRIVATE),"UTF-8"));
            jw.beginObject();
            jw.name("Date").value("Last Update: "+date);
            jw.name("Notes").value(str);
            jw.endObject();
            jw.close();
        }
        catch(Exception e)
        {
            Log.d("MainActivity.java","On Stop");
            e.printStackTrace();
        }
        Toast.makeText(getApplicationContext(),"Note Saved", Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        str=E1.getText().toString();
        dateFormat = new SimpleDateFormat("EEE, d MMM yy hh:mm:ss a");
        date=dateFormat.format(Calendar.getInstance().getTime());
        try {
            jw = new JsonWriter(new OutputStreamWriter(openFileOutput("user.json", Context.MODE_PRIVATE),"UTF-8"));
            jw.beginObject();
            jw.name("Date").value("Last Update: "+date);
            jw.name("Notes").value(str);
            jw.endObject();
            jw.close();
        }
        catch(Exception e)
        {
            Log.d("MainActivity.java","On Destory");
            e.printStackTrace();
        }
    }
}