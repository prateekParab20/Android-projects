package com.example.sujay.newsgateway;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Sujay on 4/27/2017.
 */

public class News_Artical_Async_Task extends AsyncTask<String, Integer, String> {

    private MainActivity mainActivity=new MainActivity();
    private int count;

    private final String dataURL = "https://newsapi.org/v1/articles?source=";
    private static final String TAG = "News_Source";
    private HashMap<String, String> wData = new HashMap<>();
    private String locality;
    static NewsService newsService=new NewsService();;

    public News_Artical_Async_Task(MainActivity ma) {
        mainActivity = ma;
    }
    public News_Artical_Async_Task() {
    }
    @Override
    protected void onPreExecute() {
        //Toast.makeText(mainActivity, "Loading Civic Data...", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPostExecute(String s) {
        if(s==null)
        {
            //mainActivity.no_Data_Found();
        }
        else {
            ArrayList<Articles> articles_data = parseJSON(s);
            newsService.setArticles(articles_data);
        }
    }
    @Override
    protected String doInBackground(String... params) {
        Uri dataUri;
        dataUri = Uri.parse(dataURL+params[0].toLowerCase()+"&apiKey=b92fed347fdb4605a72f30d4b640e030");
        String urlToUse = dataUri.toString();

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlToUse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            int HTTP_NOT_FOUND=conn.getResponseCode();
            if ( HTTP_NOT_FOUND == 404) {
                return null;
            }
            else
            {
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                //Log.d(TAG, "Civic data: " + sb);
                return sb.toString();

            }
        }catch(Exception e){
            return null;
        }
    }
    private ArrayList<Articles> parseJSON(String s) {
        try {
            Log.d(TAG,"parseJSON");
            ArrayList<Articles> articalList = new ArrayList<>();
            String author=null, title=null, description=null, urlToImage=null,publishedAt=null,news_url=null;
            JSONObject jObjMain = new JSONObject(s);

            JSONArray articles = jObjMain.getJSONArray("articles");
            Log.d(TAG,"Length "+articles.length());
            for (int i = 0; i < articles.length(); i++) {
                JSONObject source_object = (JSONObject) articles.get(i);

                author = source_object.getString("author");
                if(author.equals("null"))
                    author="Data Not Provided";
                title = source_object.getString("title");
                description = source_object.getString("description");
                urlToImage = source_object.getString("urlToImage");
                publishedAt = source_object.getString("publishedAt");
                if(publishedAt.equals("null"))
                    publishedAt="Data Not Provided";
                news_url = source_object.getString("url");
                //publishedAt.replace("T"," ");
                articalList.add(new Articles(author, title, description, urlToImage,publishedAt, news_url));
            }
            return articalList;
        } catch (Exception e) {
            //Log.d(TAG, "parseJSON: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}

