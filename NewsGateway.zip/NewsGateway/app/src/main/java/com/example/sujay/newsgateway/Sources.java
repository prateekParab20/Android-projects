package com.example.sujay.newsgateway;

/**
 * Created by Sujay on 4/24/2017.
 */

public class Sources {
    private String Id;
    private String Name;
    private String Url;
    private String Category;

    public Sources( String Id,
                     String Name,
                     String Url,
                     String Category
                     )
    {
        this.Id=Id;
        this.Name=Name;
        this.Url=Url;
        this.Category=Category;
    }
    public String get_Name()
    {
        return Name;
    }
    public String get_Id()
    {
        return Id;
    }
    public String get_Url()
    {
        return Url;
    }
    public String get_Category()
    {
        return Category;
    }
}

