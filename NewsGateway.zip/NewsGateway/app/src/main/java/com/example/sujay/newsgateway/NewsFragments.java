package com.example.sujay.newsgateway;

import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

/**
 * Created by Sujay on 4/24/2017.
 */

public class NewsFragments extends Fragment {
    public static final String MESSAGE_TITLE = "MESSAGE_TITLE";
    public static final String MESSAGE_DESCRIPTION = "MESSAGE_DESCRIPTION";
    public static final String MESSAGE_URL = "MESSAGE_URL";
    public static final String NEWS_NUMBER = "NEWS_NUMBER";
    public static final String NEWS_DATE = "NEWS_DATE";
    public static final String NEWS_AUTHOR = "NEWS_AUTHOR";
    public static final String NEWS_URL = "NEWS_URL";
    static MainActivity  mainActivity1;
    ImageView imageView;


    public static final NewsFragments newInstance(String title,String description, String Url,String newsnumber,String date,String author,MainActivity mainActivity,String News_Url )
    {
        NewsFragments f = new NewsFragments();
        Bundle bdl = new Bundle(1);
        bdl.putString(MESSAGE_TITLE, title);
        bdl.putString(MESSAGE_DESCRIPTION, description);
        bdl.putString(MESSAGE_URL, Url);
        bdl.putString(NEWS_NUMBER, newsnumber);
        bdl.putString(NEWS_DATE, date);
        bdl.putString(NEWS_AUTHOR, author);
        bdl.putString(NEWS_URL, News_Url);
        mainActivity1=mainActivity;
        f.setArguments(bdl);
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.my_fragment_layout, container, false);
        try {

            String title = getArguments().getString(MESSAGE_TITLE);
            //Log.d("received fragment",title);
            String description = getArguments().getString(MESSAGE_DESCRIPTION);
            String Url = getArguments().getString(MESSAGE_URL);
            String newsnumber = getArguments().getString(NEWS_NUMBER);
            String date1 = getArguments().getString(NEWS_DATE);
            String author = getArguments().getString(NEWS_AUTHOR);

            TextView titleTextView = (TextView) v.findViewById(R.id.textView);
            titleTextView.setText(title);
            TextView descriptionTextView = (TextView) v.findViewById(R.id.textView2);
            descriptionTextView.setText(description);
            TextView titleTextnumber = (TextView) v.findViewById(R.id.textView4);
            titleTextnumber.setText(newsnumber);

            TextView text_date = (TextView) v.findViewById(R.id.text_date);
            text_date.setText(date1);

            TextView text_author = (TextView) v.findViewById(R.id.author);
            text_author.setText(author);

            imageView = (ImageView) v.findViewById(R.id.imageView);
            setImage(imageView,Url);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return v;
    }

    public void setImage(final ImageView imageView1, final String Url)
    {
        if (Url==null) {
            imageView1.setImageResource(R.drawable.blankimage);
        } else {

            Picasso picasso = new Picasso.Builder(mainActivity1)
                    .listener(new Picasso.Listener() {
                        @Override
                        public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                            final String changedUrl = Url.replace("http:", "https:");
                            //Log.d(TAG, "onImageLoadFailed: ");
                            picasso.load(changedUrl)
                                    .error(R.drawable.brokenimage)
                                    .placeholder(R.drawable.placeholder)
                                    .resize(200, 200)
                                    .memoryPolicy(MemoryPolicy.NO_CACHE)
                                    .into(imageView1);
                        }
                    })
                    .build();

            picasso.load(Url)
                    .error(R.drawable.brokenimage)
                    .resize(200,200 )
                    .placeholder(R.drawable.placeholder)
                    .memoryPolicy(MemoryPolicy.NO_CACHE)
                    .into(imageView1);
        }
    }

}
