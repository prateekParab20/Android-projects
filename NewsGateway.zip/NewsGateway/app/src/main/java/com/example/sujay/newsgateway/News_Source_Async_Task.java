package com.example.sujay.newsgateway;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Sujay on 4/24/2017.
 */

public class News_Source_Async_Task extends AsyncTask<String, Integer, String> {

    private MainActivity mainActivity=new MainActivity();
    private int count;

    private final String dataURL = "https://newsapi.org/v1/sources?language=en&country=us&apiKey=b92fed347fdb4605a72f30d4b640e030";
    private final String dataURL2 = "https://newsapi.org/v1/sources?language=en&country=us&category=";
    private static final String TAG = "News_Source";
    private HashMap<String, String> wData = new HashMap<>();
    private String locality;

    public News_Source_Async_Task(MainActivity ma) {
        mainActivity = ma;
    }

    @Override
    protected void onPreExecute() {
        //Toast.makeText(mainActivity, "Loading Civic Data...", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPostExecute(String s) {
        if(s==null)
        {
            mainActivity.no_Data_Found();
        }
        else {
            ArrayList<Sources> sources_data = parseJSON(s);
            mainActivity.sources_data_to_add(sources_data);
        }
    }
    @Override
    protected String doInBackground(String... params) {
        Uri dataUri;
        if(params.length ==0) {
            dataUri = Uri.parse(dataURL);
        }
        else
            if(params[0].equals("all"))
            {
                dataUri = Uri.parse(dataURL);
            }
            else
                dataUri=Uri.parse(dataURL2+params[0]+"&apiKey=b92fed347fdb4605a72f30d4b640e030");
        String urlToUse = dataUri.toString();

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlToUse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            int HTTP_NOT_FOUND=conn.getResponseCode();
            if ( HTTP_NOT_FOUND == 404) {
                return null;
            }
            else
            {
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                //Log.d(TAG, "Civic data: " + sb);
                return sb.toString();

            }
        }catch(Exception e){
            return null;
        }
    }
    private ArrayList<Sources> parseJSON(String s) {
        try {
            Log.d(TAG,"parseJSON");
            HashMap office_map = new HashMap<String, String>();
            ArrayList<Sources> sourcesList = new ArrayList<>();
            String Name=null, Id=null, Category=null, Url=null;
            JSONObject jObjMain = new JSONObject(s);
            JSONArray sources = jObjMain.getJSONArray("sources");
            Log.d(TAG,"Length "+sources.length());
            for (int i = 0; i < sources.length(); i++) {
                JSONObject source_object = (JSONObject) sources.get(i);
                Id = source_object.getString("id");
                Name = source_object.getString("name");
                Url = source_object.getString("url");
                Category = source_object.getString("category");
                sourcesList.add(new Sources(Id, Name, Url, Category));
            }

            return sourcesList;

        } catch (Exception e) {
            //Log.d(TAG, "parseJSON: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}

