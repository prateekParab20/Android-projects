package com.example.sujay.newsgateway;

/**
 * Created by Sujay on 4/27/2017.
 */

public class Articles  {
    private String author;
    private String title;
    private String description;
    private String urlToImage;
    private String publishedAt;
    private String news_url;

    public Articles(String author,
                    String title,
                    String description,
                    String urlToImage,
                    String publishedAt,
                    String news_url
    )
    {
        this.author=author;
        this.title=title;
        this.description=description;
        this.urlToImage=urlToImage;
        this.publishedAt=publishedAt;
        this.news_url=news_url;
    }
    public String get_Author()
    {
        return author;
    }
    public String get_Title()
    {
        return title;
    }
    public String get_Description()
    {
        return description;
    }
    public String get_UrlToImage()
    {
        return urlToImage;
    }
    public String get_PublishedAt()
    {
        return publishedAt;
    }
    public String get_News_url()
    {
        return news_url;
    }

}

