package com.example.sujay.newsgateway;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;

import java.util.ArrayList;

/**
 * Created by Sujay on 4/27/2017.
 */
public class NewsService extends Service  {

    private static final String TAG = "NewsService";
    private boolean running = true;
    static ArrayList<Articles> NewsService_story_list=new ArrayList<>();
    static final String ACTION_MSG_TO_SERVICE = "ACTION_MSG_TO_SERVICE";
    private MainActivity.NewsReceiver newsReceiver1;
    static NewsServiceReceiver newsServiceReceiver;
    String Title[];
    String Desc[];
    String Urldata[];
    String publishedAt[];
    String author[];
    String news_url[];
    public NewsService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        newsServiceReceiver= new NewsServiceReceiver();
        IntentFilter filter2 = new IntentFilter(ACTION_MSG_TO_SERVICE);
        registerReceiver(newsServiceReceiver, filter2);

        new Thread(new Runnable() {
            @Override
            public void run() {
                    if (!running) {
                        //Log.d(TAG, "run: Thread loop stopped early");
                    }
                    try {
                        while(true) {
                            //Log.d(TAG, "While Loop");
                            if(NewsService_story_list.size()==0)
                                Thread.sleep(250);
                            else
                                sendMessage("Service Broadcast Message " );
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
            }
        }).start();
        return START_STICKY;
    }
    public void setArticles(ArrayList<Articles> articles_data)
    {
        NewsService_story_list.clear();
        NewsService_story_list=articles_data;
    }
    private void sendMessage(String msg) {
        Intent intent = new Intent();
        intent.setAction(MainActivity.ACTION_NEWS_STORY);
         Title= new String[NewsService_story_list.size()];
         Desc= new String[NewsService_story_list.size()];
         Urldata= new String[NewsService_story_list.size()];
         publishedAt= new String[NewsService_story_list.size()];
         author= new String[NewsService_story_list.size()];
         news_url= new String[NewsService_story_list.size()];

        for(int i =0;i<NewsService_story_list.size();i++)
        {
            Title[i]=NewsService_story_list.get(i).get_Title();
            Desc[i]=NewsService_story_list.get(i).get_Description();
            Urldata[i]=NewsService_story_list.get(i).get_UrlToImage();
            publishedAt[i]=NewsService_story_list.get(i).get_PublishedAt();
            author[i]=NewsService_story_list.get(i).get_Author();
            news_url[i]=NewsService_story_list.get(i).get_News_url();
        }
        intent.putExtra(MainActivity.ARTICLES_DATA,Title);
        intent.putExtra("DESC",Desc);
        intent.putExtra("URL",Urldata);
        intent.putExtra("Author",author);
        intent.putExtra("publishedAt",publishedAt);
        intent.putExtra("News_Url",news_url);
        sendBroadcast(intent);
        NewsService_story_list.clear();
    }
    @Override
    public void onDestroy() {
        unregisterReceiver(newsServiceReceiver);
        running = false;
        super.onDestroy();
    }
class NewsServiceReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        switch (intent.getAction()) {
            case ACTION_MSG_TO_SERVICE:
                if (intent.hasExtra("SOURCE_DATA")) {
                    new News_Artical_Async_Task().execute(intent.getStringExtra("SOURCE_DATA"));
                }
                break;
        }
    }
}
}
