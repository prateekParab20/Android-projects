package com.example.prate.knowyourgovernment;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sujay.knowyourgovernment.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, View.OnLongClickListener {
    private static final String TAG = "MainActivity";
    private RecyclerView recyclerView;
    private RecyclerViewAdapter mAdapter;
    String address;
    private Locator locator;
    int Edit_post;
    EditText et;
    TextView currentaddress;
    private static final int  Edit_REQ= 2;


    static List<Official> officialList=new ArrayList<Official>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ConnectivityManager connMgr = (ConnectivityManager)
        getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        boolean isWifiConn = networkInfo.isConnected();
        networkInfo = connMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        boolean isMobileConn = networkInfo.isConnected();
        setContentView(R.layout.activity_main);
        recyclerView = (RecyclerView) findViewById(R.id.recycler);
        recyclerView.setScrollbarFadingEnabled(true);
        recyclerView.setVerticalScrollBarEnabled(true);
        mAdapter = new RecyclerViewAdapter(officialList, this);
        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        currentaddress =(TextView) findViewById(R.id.main_activity_address);

        if(isWifiConn==true || isMobileConn==true ) {
        locator = new Locator(this);
        locator.setUpLocationManager();
        locator.determineLocation();
        new Civic_Information_AsyncTask(MainActivity.this).execute(address);
        mAdapter.notifyDataSetChanged();
        }
        else
        {
            currentaddress.setText("No Data For Location");
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Data cannot be accessed/loaded Without an Internet Connection");
            builder.setTitle("No Network Connection");
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_activity_menu, menu);
        return true;
    }
    private String doAddress(double latitude, double longitude) {

        Log.d(TAG, "doAddress: Lat: " + latitude + ", Lon: " + longitude);

        List<Address> addresses = null;
        for (int times = 0; times < 3; times++) {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            try {
                Log.d(TAG, "doAddress: Getting address now");
                addresses = geocoder.getFromLocation(latitude, longitude, 1);
                StringBuilder sb = new StringBuilder();
                for (Address ad : addresses) {
                    Log.d(TAG, "doLocation: " + ad);
                    sb.append(ad.getLocality()+", "+ad.getAdminArea());
                    sb.append("$"+ad.getPostalCode());

                }
                Log.d(TAG, "Address iS ***********" + sb);
                return sb.toString();
            } catch (IOException e) {
                Log.d(TAG, "doAddress: " + e.getMessage());
            }
            Toast.makeText(this, "GeoCoder service is slow - please wait", Toast.LENGTH_SHORT).show();
        }
        Toast.makeText(this, "GeoCoder service timed out - please try again", Toast.LENGTH_LONG).show();
        return null;
    }
    public void setData(double lat, double lon) {
        address = doAddress(lat, lon);
        //currentaddress.setText(address.replace("$"," "));
        //Toast.makeText(this, address.substring(address.indexOf("$")), Toast.LENGTH_LONG).show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        Log.d(TAG, "onRequestPermissionsResult: CALL: " + permissions.length);
        Log.d(TAG, "onRequestPermissionsResult: PERM RESULT RECEIVED");

        if (requestCode == 5) {
            Log.d(TAG, "onRequestPermissionsResult: permissions.length: " + permissions.length);
            for (int i = 0; i < permissions.length; i++) {
                if (permissions[i].equals(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        Log.d(TAG, "onRequestPermissionsResult: HAS PERM");
                        locator.setUpLocationManager();
                        locator.determineLocation();
                    } else {
                        Toast.makeText(this, "Location permission was denied - cannot determine address", Toast.LENGTH_LONG).show();
                        Log.d(TAG, "onRequestPermissionsResult: NO PERM");
                    }
                }
            }
        }
        Log.d(TAG, "onRequestPermissionsResult: Exiting onRequestPermissionsResult");
    }
    public void civic_Data_to_add( ArrayList<Official> civic_data) {
        //Toast.makeText(this, "Civic data Received", Toast.LENGTH_LONG).show();
        officialList.clear();
        //Log.d("asdasdasdsadasdasd",Integer.toString(civic_data.size()));
        for(int i=0;i<civic_data.size();i++)
        {
            officialList.add(civic_data.get(i));
            address=civic_data.get(i).get_Locality();
            currentaddress.setText(address);
        }
        mAdapter.notifyDataSetChanged();
    }
    public void noLocationAvailable() {
        Toast.makeText(this, "No location providers were available", Toast.LENGTH_LONG).show();
    }
    public void no_Data_Found()
    {
        AlertDialog.Builder buildera = new AlertDialog.Builder(MainActivity.this);
        buildera.setMessage("Data for Location Not Found");
        buildera.setTitle("Not Found:");
        AlertDialog dialoga = buildera.create();
        dialoga.show();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menuA:
                Intent intent1=new Intent(this,AboutActivity.class);
                //Toast.makeText(this,"About Stock Pressed !!!",Toast.LENGTH_SHORT).show();
                startActivity(intent1);
                return true;
            case R.id.menuB:
                ConnectivityManager connMgr = (ConnectivityManager)
                        getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = connMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                boolean isWifiConn = networkInfo.isConnected();
                networkInfo = connMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                boolean isMobileConn = networkInfo.isConnected();
                if(isWifiConn==true || isMobileConn==true ) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    et = new EditText(this);
                    et.setFilters(new InputFilter[]{new InputFilter.AllCaps()});
                    et.setAllCaps(true);
                    et.setInputType(InputType.TYPE_CLASS_TEXT);
                    et.setGravity(Gravity.CENTER_HORIZONTAL);
                    et.setTextColor(Color.parseColor("#ff000000"));
                    builder.setView(et);
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            new Civic_Information_AsyncTask(MainActivity.this).execute(et.getText().toString());
                        }
                    });
                    builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User cancelled the dialog
                        }
                    });
                    builder.setMessage("Enter a City, State or a Zip Code:");
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    return true;
                }
                else
                {
                    //currentaddress.setText("No Data For Location");
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Data cannot be accessed/loaded Without an Internet Connection");
                    builder.setTitle("No Network Connection");
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public void onClick(View v) {

        Toast.makeText(MainActivity.this,"On click called !!!",Toast.LENGTH_LONG);
        int pos = recyclerView.getChildLayoutPosition(v);

        Edit_post = pos;
        Official n = officialList.get(pos);
        Intent intent3=new Intent(this,OfficialActivity.class);
        intent3.putExtra("Official_Name",n.get_Name());
        intent3.putExtra("Official_Party",n.get_Party());
        intent3.putExtra("Current_Location",address);

        if(n.get_Office_Address()==null)
            intent3.putExtra("Official_Address","No Data Provided");
        else
            intent3.putExtra("Official_Address",n.get_Office_Address());

        if(n.get_Office()==null)
            intent3.putExtra("Official_Office","No Data Provided");
        else
            intent3.putExtra("Official_Office",n.get_Office());

        if(n.get_Phone_Number()==null)
            intent3.putExtra("Official_Phone","No Data Provided");
        else
            intent3.putExtra("Official_Phone",n.get_Phone_Number());

        if(n.get_Email_Address()==null)
            intent3.putExtra("Official_Email","No Data Provided");
        else
            intent3.putExtra("Official_Email",n.get_Email_Address());
        if(n.get_Website()==null)
            intent3.putExtra("Official_WebSite","No Data Provided");
        else
            intent3.putExtra("Official_WebSite",n.get_Website());

        if(n.get_PhotoUrl()==null)
            intent3.putExtra("Official_Photo","No Data Provided");
        else
            intent3.putExtra("Official_Photo",n.get_PhotoUrl());

        if(n.get_FB_id()==null)
            intent3.putExtra("FB_id","No Data Provided");
        else
            intent3.putExtra("FB_id",n.get_FB_id());

        if(n.get_Googleplus_id()==null)
            intent3.putExtra("Googleplus_id","No Data Provided");
        else
            intent3.putExtra("Googleplus_id",n.get_Googleplus_id());

        if(n.get_Twitter_id()==null)
            intent3.putExtra("Twitter_id","No Data Provided");
        else
            intent3.putExtra("Twitter_id",n.get_Twitter_id());

        if(n.get_YouTube_id()==null)
            intent3.putExtra("YouTube_id","No Data Provided");
        else
            intent3.putExtra("YouTube_id",n.get_YouTube_id());

        startActivityForResult(intent3, Edit_REQ);
        Log.d(TAG, "On click called !!!");
    }
    public boolean onLongClick(View v) {

        Toast.makeText(MainActivity.this,"On Long click called !!!",Toast.LENGTH_LONG);
        Log.d(TAG, "On Long click called !!!");
        return false;
    }
}