package com.example.prate.knowyourgovernment;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;


public class Civic_Information_AsyncTask extends AsyncTask<String, Integer, String> {
    private MainActivity mainActivity=new MainActivity();
    private int count;

    private final String dataURL = "https://www.googleapis.com/civicinfo/v2/representatives?key=AIzaSyCS4O2KbJ9a5rCjhsFXOooM9LgWOVJGVLo&address=";
    private static final String TAG = "Civic_Information";
    private HashMap<String, String> wData = new HashMap<>();
    private String locality;

    public Civic_Information_AsyncTask(MainActivity ma) {
        mainActivity = ma;
    }

    @Override
    protected void onPreExecute() {
        Toast.makeText(mainActivity, "Loading Civic Data...", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPostExecute(String s) {
        if(s==null)
        {
            mainActivity.no_Data_Found();
        }
        else {
            ArrayList<Official> civic_data = parseJSON(s);
            mainActivity.civic_Data_to_add(civic_data);
        }
    }
    @Override
    protected String doInBackground(String... params) {
        Uri dataUri = Uri.parse(dataURL+params[0]);
        String urlToUse = dataUri.toString();

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlToUse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            int HTTP_NOT_FOUND=conn.getResponseCode();
            if ( HTTP_NOT_FOUND == 404) {
                return null;
            }
            else
            {
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                //Log.d(TAG, "Civic data: " + sb);
                return sb.toString();

            }
        }catch(Exception e){
            return null;
        }
    }

    private ArrayList<Official> parseJSON(String s) {
        try {
            HashMap office_map=new HashMap<String,String>();
            ArrayList<Official> officialList = new ArrayList<>();

            JSONObject jObjMain = new JSONObject(s);
            JSONObject normalizedInput = jObjMain.getJSONObject("normalizedInput");
            locality=normalizedInput.getString("city");
            locality+=", "+normalizedInput.getString("state");
            locality+=" "+normalizedInput.getString("zip");
            //Log.d(TAG, "Don:!!!!!!!1 " + normalizedInput.getString("city")+" "+normalizedInput.getString("state")+" "+normalizedInput.getString("zip"));

            JSONArray offices =  jObjMain.getJSONArray("offices");
            //Log.d(TAG,offices.toString());
            for (int i = 0; i < offices.length(); i++) {
                //Log.d(TAG, "offices "+i+"");
                JSONObject offices_object=(JSONObject)offices.get(i);
                //Log.d(TAG,offices_object.toString());
                //office_map.put(offices_object.get("name"),);
                JSONArray offices_index =  offices_object.getJSONArray("officialIndices");
                //Log.d(TAG,"Length "+offices_index);
                for (int j = 0; j < offices_index.length(); j++) {
                    office_map.put(offices_index.get(j).toString(),offices_object.get("name"));
                }
            }
            Log.d(TAG,office_map.toString());
            JSONArray officials =  jObjMain.getJSONArray("officials");
            for (int j = 0; j < officials.length(); j++) {
                JSONObject official_data = officials.getJSONObject(j);
                String Office = null;
                String Name = null;
                String Party = null;
                String Office_Address=null;
                String Phone_Number = null;
                String Email_Address = null;
                String Website = null;
                String PhotoUrl = null;
                String FB_id = null;
                String Twitter_id = null;
                String Googleplus_id = null;
                String YouTube_id = null;
                Office=office_map.get(Integer.toString(j)).toString();
                if (official_data.has("name")) {
                    Name = official_data.getString("name");
                }
                if (official_data.has("address")) {
                    JSONArray officials_address = official_data.getJSONArray("address");

                    JSONObject Office_Address1 = officials_address.getJSONObject(0);
                    if (Office_Address1.has("line1")) {
                        Office_Address = Office_Address1.getString("line1") + " ";
                    }
                    if (Office_Address1.has("line2")) {
                        Office_Address += Office_Address1.getString("line2") + " ";
                    }
                    if (Office_Address1.has("line3")) {
                        Office_Address += Office_Address1.getString("line3") + " ";
                    }
                    //Office_Address+="\n";
                    if (Office_Address1.has("city")) {
                        Office_Address += Office_Address1.getString("city") + ", ";
                    }
                    if (Office_Address1.has("state")) {
                        Office_Address += Office_Address1.getString("state") + " ";
                    }
                    if (Office_Address1.has("zip")) {
                        Office_Address += Office_Address1.getString("zip");
                    }
                }
                //Office_Address= +Office_Address1.getString("")+", "+Office_Address1.getString("")+", "+Office_Address1.getString("");
                if (official_data.has("party")) {
                    Party = official_data.getString("party");
                }

                if (official_data.has("phones")) {
                JSONArray officials_phone_numbers = official_data.getJSONArray("phones");
                for (int i = 0; i < officials_phone_numbers.length(); i++) {
                    Phone_Number = officials_phone_numbers.get(i) + "";
                    break;
                }
            }
                if (official_data.has("urls")) {
                    JSONArray officials_urls = official_data.getJSONArray("urls");
                    for (int i = 0; i < officials_urls.length(); i++) {
                        Website = officials_urls.get(i) + "";
                        break;
                    }
                }
                if (official_data.has("photoUrl")) {
                    PhotoUrl = official_data.getString("photoUrl");
                }
                if(official_data.has("channels")) {
                    JSONArray officials_channels = official_data.getJSONArray("channels");
                    for (int i = 0; i < officials_channels.length(); i++) {
                        JSONObject JSON_channels = (JSONObject) officials_channels.get(i);
                        if (JSON_channels.getString("type").equals("GooglePlus")) {
                            Googleplus_id = JSON_channels.getString("id");
                        } else if (JSON_channels.getString("type").equals("Facebook")) {
                            FB_id = JSON_channels.getString("id");
                        } else if (JSON_channels.getString("type").equals("Twitter")) {
                            Twitter_id = JSON_channels.getString("id");
                        } else if (JSON_channels.getString("type").equals("YouTube")) {
                            YouTube_id = JSON_channels.getString("id");
                        }
                    }
                }
                officialList.add(new Official(locality,Office,Name,Party,Office_Address,Phone_Number, Email_Address, Website, PhotoUrl, FB_id, Twitter_id, Googleplus_id, YouTube_id));
                //Log.d(TAG,"Here"+officialList.size());
                Log.d(TAG,"Here"+Office+" "+Name+" "+Party+" "+Office_Address+" "+Phone_Number+" "+Website+" "+PhotoUrl);
            }
            return officialList;

        } catch (Exception e) {
            //Log.d(TAG, "parseJSON: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
