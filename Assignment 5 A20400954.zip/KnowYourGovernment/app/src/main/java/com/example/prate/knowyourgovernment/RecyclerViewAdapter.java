package com.example.prate.knowyourgovernment;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.sujay.knowyourgovernment.R;

import java.util.List;



public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewHolder> {

    private List<Official> officialList;
    private MainActivity mainActivity;

    public RecyclerViewAdapter(List<Official> officialList,MainActivity mainActivity )
    {
        this.officialList=officialList;
        this.mainActivity=mainActivity;
    }
    @Override
    public RecyclerViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.officials_list, parent, false);

        itemView.setOnClickListener(mainActivity);
        itemView.setOnLongClickListener(mainActivity);
        return new RecyclerViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        Official official = officialList.get(position);
        holder.official_name.setText(official.get_Name()+"("+official.get_Party()+")");
        holder.official_post.setText(official.get_Office());
    }
    public int getItemCount() {
        return officialList.size();
    }



}
