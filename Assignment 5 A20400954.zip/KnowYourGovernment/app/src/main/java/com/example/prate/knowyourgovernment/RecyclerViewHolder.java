package com.example.prate.knowyourgovernment;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.sujay.knowyourgovernment.R;


public class RecyclerViewHolder extends RecyclerView.ViewHolder {

    public TextView official_name;
    public TextView official_post;

    public RecyclerViewHolder(View view)
    {
        super(view);
        official_name=(TextView) view.findViewById(R.id.officials_name);
        official_post=(TextView) view.findViewById(R.id.officials_post);
    }
}
