package com.example.prate.knowyourgovernment;



public class Official {
    private String Office;
    private String Name;
    private String Party;
    private String Office_Address;
    private String Phone_Number;
    private String Email_Address;
    private String Website;
    private String PhotoUrl;
    private String FB_id;
    private String Twitter_id;
    private String Googleplus_id;
    private String YouTube_id;
    private String Locality;

    public Official( String Locality,
            String Office,
            String Name,
            String Party,
            String Office_Address,
            String Phone_Number,
            String Email_Address,
            String Website,
            String PhotoUrl,
            String FB_id,
            String Twitter_id,
            String Googleplus_id,
            String YouTube_id)
    {
            this.Locality=Locality;
            this.Office=Office;
            this.Name=Name;
            this.Party=Party;
            this.Office_Address=Office_Address;
            this.Phone_Number=Phone_Number;
            this.Email_Address=Email_Address;
            this.Website=Website;
            this.PhotoUrl=PhotoUrl;
            this.FB_id=FB_id;
            this.Twitter_id=Twitter_id;
            this.Googleplus_id=Googleplus_id;
            this.YouTube_id=YouTube_id;
    }
    public String get_Name()
    {
        return Name;
    }
    public String get_Office()
    {
        return Office;
    }
    public String get_Party()
    {
        return Party;
    }
    public String get_Office_Address()
    {
        return Office_Address;
    }
    public String get_Phone_Number()
    {
        return Phone_Number;
    }
    public String get_Email_Address()
    {
        return Email_Address;
    }
    public String get_Website()
    {
        return Website;
    }
    public String get_PhotoUrl()
    {
        return PhotoUrl;
    }
    public String get_FB_id()
    {
        return FB_id;
    }
    public String get_Twitter_id()
    {
        return Twitter_id;
    }
    public String get_Googleplus_id()
    {
        return Googleplus_id;
    }
    public String get_YouTube_id()
    {
        return YouTube_id;
    }
    public String get_Locality()
    {
        return Locality;
    }
}

