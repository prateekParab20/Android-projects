package com.example.prate.knowyourgovernment;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sujay.knowyourgovernment.R;
import com.squareup.picasso.Picasso;



public class PhotoActivity extends AppCompatActivity {
    TextView textView1,textView2,textView3;
    String official_party;
    ConstraintLayout constraintLayout;
    ImageView imageView;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.photo_layout);
        imageView = (ImageView) findViewById(R.id.photo_official_photo);
        textView1= (TextView) findViewById(R.id.photo_official_name);
        textView2= (TextView) findViewById(R.id.photo_offcial_department);
        textView3= (TextView) findViewById(R.id.photo_address);
        imageView=(ImageView)  findViewById(R.id.photo_official_photo);
        constraintLayout=(ConstraintLayout) findViewById(R.id.photo_constraint);
        Intent intent = getIntent();
        ActionBar actionBar=getSupportActionBar();
        String image_Url=intent.getStringExtra("Official_Photo_Url");
        textView1.setText(intent.getStringExtra("Official_Name"));
        textView2.setText(intent.getStringExtra("Office_designation"));
        textView3.setText(intent.getStringExtra("Current_Location"));
        official_party=intent.getStringExtra("Offical_Party");
        Log.d("Image Loading", "loadImage: " + image_Url);
        if(official_party.toLowerCase().equals("(republican)"))
        {
            constraintLayout.setBackgroundColor(Color.parseColor("#ffcc0000"));
        }
        else if(official_party.toLowerCase().equals("(democratic)"))
        {
            constraintLayout.setBackgroundColor(Color.parseColor("#ff0099cc"));
        }
        else
            constraintLayout.setBackgroundColor(Color.parseColor("#ff000000"));
        loadImage(image_Url);
    }
    private void loadImage(final String imageURL) {
        if (imageURL.equals("No Data Provided")) {
            imageView.setImageResource(R.drawable.blankimage);
        } else {
            Picasso picasso = new Picasso.Builder(this)
                    .listener(new Picasso.Listener() {
                        @Override
                        public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                            final String changedUrl = imageURL.replace("http:", "https:");
                            //Log.d(TAG, "onImageLoadFailed: ");
                            picasso.load(changedUrl)
                                    .error(R.drawable.brokenimage)
                                    .placeholder(R.drawable.placeholder)
                                    .into(imageView);
                        }
                    })
                    .build();

            picasso.load(imageURL)
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.placeholder)
                    .into(imageView);
        }
    }
    }
