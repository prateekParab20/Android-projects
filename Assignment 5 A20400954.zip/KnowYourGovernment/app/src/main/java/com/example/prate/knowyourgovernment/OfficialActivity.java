package com.example.prate.knowyourgovernment;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sujay.knowyourgovernment.R;
import com.squareup.picasso.Picasso;


public class OfficialActivity extends AppCompatActivity {
    TextView official_name;
    TextView official_Office;
    TextView official_party;
    TextView official_Office_Address;
    TextView official_Office_location;
    TextView official_Phone_Number;
    TextView official_Email_Address;
    TextView official_Website;
    TextView designation;
    ImageView imageView;
    String image_Url;
    String party_name;
    ConstraintLayout constraintLayout;
    ImageView Fb_image,Google_plus,Twitter_image,Youtube_image;
    String Fb_image1,Google_plus1,Twitter_image1,Youtube_image1;
    private static final int  Edit_REQ= 2;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar=getSupportActionBar();
        setContentView(R.layout.official_activity);
        imageView = (ImageView) findViewById(R.id.imageView);

        official_name=(TextView) findViewById(R.id.offcial_name);
        official_Office=(TextView) findViewById(R.id.designation);
        official_party=(TextView) findViewById(R.id.party_name);
        designation=(TextView) findViewById(R.id.designation);
        official_Office_location=(TextView) findViewById(R.id.current_address);
        //Linkify.addLinks(((TextView) findViewById(R.id.address)), Linkify.MAP_ADDRESSES);

        official_Office_Address=(TextView) findViewById(R.id.address);
        Linkify.addLinks(official_Office_Address, Linkify.ALL);

        Linkify.addLinks(((TextView) findViewById(R.id.phone_number)), Linkify.PHONE_NUMBERS);
        official_Phone_Number=(TextView) findViewById(R.id.phone_number);

        Linkify.addLinks(((TextView) findViewById(R.id.email_id)), Linkify.EMAIL_ADDRESSES);
        official_Email_Address=(TextView) findViewById(R.id.email_id);

        official_Website=(TextView) findViewById(R.id.offcial_website);
        Linkify.addLinks(official_Website, Linkify.WEB_URLS);

        constraintLayout=(ConstraintLayout) findViewById(R.id.official_constraint);

        Fb_image=(ImageView) findViewById(R.id.FB_image);
        Google_plus=(ImageView) findViewById(R.id.Googleplus_image);
        Youtube_image=(ImageView) findViewById(R.id.Youtube_image);
        Twitter_image=(ImageView) findViewById(R.id.Twitter_image);

        Intent intent = getIntent();
        official_name.setText(intent.getStringExtra("Official_Name"));
        designation.setText(intent.getStringExtra("Official_Office"));
        party_name=intent.getStringExtra("Official_Party");
        official_party.setText("("+party_name+")");
        official_Office_location.setText(intent.getStringExtra("Current_Location"));

        official_Office_Address.setText(intent.getStringExtra("Official_Address"));
        Linkify.addLinks(official_Office_Address, Linkify.ALL);
        //Linkify.addLinks(official_Office_Address, Linkify.MAP_ADDRESSES);

        official_Phone_Number.setText(intent.getStringExtra("Official_Phone"));
        Linkify.addLinks(official_Phone_Number, Linkify.ALL);
        //Linkify.addLinks(official_Phone_Number, Linkify.PHONE_NUMBERS);

        official_Email_Address.setText(intent.getStringExtra("Official_Email"));
        Linkify.addLinks(official_Email_Address, Linkify.ALL);
        //Linkify.addLinks(official_Email_Address, Linkify.EMAIL_ADDRESSES);

        official_Website.setText(intent.getStringExtra("Official_WebSite"));
        Linkify.addLinks(official_Website, Linkify.ALL);
        //Linkify.addLinks(official_Website, Linkify.WEB_URLS);
        image_Url=intent.getStringExtra("Official_Photo");
        loadImage(image_Url);
        if(party_name!=null) {
            if (party_name.toLowerCase().equals("republican")) {
                constraintLayout.setBackgroundColor(Color.parseColor("#ffcc0000"));
            } else if (party_name.toLowerCase().equals("democratic")) {
                constraintLayout.setBackgroundColor(Color.parseColor("#ff0099cc"));
            } else
                constraintLayout.setBackgroundColor(Color.parseColor("#ff000000"));
        }
        Fb_image1=intent.getStringExtra("FB_id");
        if(Fb_image1.equals("No Data Provided"))
        {
            Fb_image.setVisibility(View.INVISIBLE);
        }
        Google_plus1=intent.getStringExtra("Googleplus_id");
        if(Google_plus1.equals("No Data Provided"))
        {
            Google_plus.setVisibility(View.INVISIBLE);
        }
        Twitter_image1=intent.getStringExtra("Twitter_id");
        if(Twitter_image1.equals("No Data Provided"))
        {
            Twitter_image.setVisibility(View.INVISIBLE);
        }
        Youtube_image1=intent.getStringExtra("YouTube_id");
        if(Youtube_image1.equals("No Data Provided"))
        {
            Youtube_image.setVisibility(View.INVISIBLE);
        }
    }
    /*public void loadImage(View v) {
        loadImage(image_Url);
    }*/
    public void facebookClicked(View v) {
        if(!Fb_image1.equals("No Data Provided")) {
            String FACEBOOK_URL = "https://www.facebook.com/" + Fb_image1;
            String urlToUse = null;
            PackageManager packageManager = getPackageManager();
            try {
                int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
                if (versionCode >= 3002850) {
                    //newer versions of fb app
                    urlToUse = "fb://facewebmodal/f?href=" + FACEBOOK_URL;
                }
           /* else
            { //older versions of fb app
                urlToUse = "fb://page/" + channels.get("Facebook");
            }*/
            } catch (PackageManager.NameNotFoundException e) {
                urlToUse = FACEBOOK_URL; //normal web url
            }
            Intent facebookIntent = new Intent(Intent.ACTION_VIEW);
            facebookIntent.setData(Uri.parse(urlToUse));
            startActivity(facebookIntent);
        }
    }
    public void twitterClicked(View v)
    {
        if(!Twitter_image1.equals("No Data Provided")) {
            Intent intent = null;
            String name = Twitter_image1;
            try {
                // get the Twitter app if possible
                getPackageManager().getPackageInfo("com.twitter.android", 0);
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?screen_name=" + name));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            } catch (Exception e) {
                // no Twitter app, revert to browser
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/" + name));
            }
            startActivity(intent);
        }
    }
    public void googlePlusClicked(View v)
    {
        if(!Google_plus1.equals("No Data Provided")) {
            String name = Google_plus1;
            Intent intent = null;
            try {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setClassName("com.google.android.apps.plus", "com.google.android.apps.plus.phone.UrlGatewayActivity");
                intent.putExtra("customAppUri", name);
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://plus.google.com/" + name)));
            }
        }
    }
    public void youTubeClicked(View v)
    {
        if(!Youtube_image1.equals("No Data Provided")) {
            String name = Youtube_image1;
            Intent intent = null;
            try {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setPackage("com.google.android.youtube");
                intent.setData(Uri.parse("https://www.youtube.com/" + name));
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/" + name)));
            }
        }
    }
    private void loadImage(final String imageURL) {
        //     compile 'com.squareup.picasso:picasso:2.5.2'
        //Log.d(TAG, "loadImage: " + imageURL);
        if(imageURL.equals("No Data Provided"))
        {
            imageView.setImageResource(R.drawable.blankimage);
        }
        else {
            Picasso picasso = new Picasso.Builder(this)
                    .listener(new Picasso.Listener() {
                        @Override
                        public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                            final String changedUrl = imageURL.replace("http:", "https:");
                            //Log.d(TAG, "onImageLoadFailed: ");
                            picasso.load(changedUrl)
                                    .error(R.drawable.brokenimage)
                                    .placeholder(R.drawable.placeholder)
                                    .into(imageView);
                        }
                    })
                    .build();

            picasso.load(imageURL)
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.placeholder)
                    .into(imageView);
        }
    }
    public void imageClick(View v) {
        Intent intent1=new Intent(this,PhotoActivity.class);
        intent1.putExtra("Official_Photo_Url",image_Url);
        Log.d("sadasd", image_Url);
        intent1.putExtra("Official_Name",official_name.getText());
        intent1.putExtra("Office_designation",designation.getText());
        intent1.putExtra("Current_Location",official_Office_location.getText());
        intent1.putExtra("Offical_Party",official_party.getText());
        startActivityForResult(intent1, Edit_REQ);
        Log.d("sadasd", "Image Clicked !!!");
        //Toast.makeText(this, "You clicked an ImageView with an onClick!", Toast.LENGTH_SHORT).show();
    }
}

